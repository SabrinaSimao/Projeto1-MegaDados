# BigData2018
Repo for the BigData discipline at insper
