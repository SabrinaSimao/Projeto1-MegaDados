import request from "superagent";

export const insertRecipe = () => {
  request.post("http://localhost:3002/api/geleias")
    .set("Content-Type", 'application/json')
    .send({ })
    .end(function(err, res) {
      console.log(res.text);
    });
};

export const removeRecipe = () => {
  request.patch("http://localhost:3002/api/geleias")
    .set("Content-Type", "application/json")
    .send({})
    .end(function(err, res) {
      console.log(res.text);
    });
};