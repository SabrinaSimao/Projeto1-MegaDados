import React, { Component } from 'react';
import logo from './logo.svg';
import Button from '../src/Button';
import './App.css';
import { insertRecipe,removeRecipe } from './databaseHelper.js';

class App extends Component {

  constructor(props){
    super(props);

    this.handleInsert = this.handleInsert.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
  }

  handleInsert() {
    insertRecipe();
  }

  handleDelete() {
    removeRecipe();
  }

  render() {
    return (
      <div className="App">
        <div className='button-container'>
        <Button
          text="Clique e confira o console log "
          onClick={this.handleInsert}
        />
        </div>
      </div>
    );
  }
}

export default App;
