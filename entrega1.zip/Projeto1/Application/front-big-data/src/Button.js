import React, { Component } from "react";
import './App.css';

class Button extends Component {
  render() {
    return (
      <button onClick={this.props.onClick} className='default-button'>
        {this.props.text}
      </button>
    );
  }
}

export default Button;
